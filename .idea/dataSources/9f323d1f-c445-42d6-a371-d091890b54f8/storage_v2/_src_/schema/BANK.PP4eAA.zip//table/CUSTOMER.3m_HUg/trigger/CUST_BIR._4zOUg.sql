create trigger CUST_BIR
    before insert
    on CUSTOMER
    for each row
BEGIN
    SELECT cust_seq.NEXTVAL
    INTO   :new.Cid
    FROM   dual;
END;
/

